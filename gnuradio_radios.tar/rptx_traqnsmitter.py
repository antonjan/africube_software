#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: This is a demo of how to transmit with rpitx
# Author: Anton Janovsky (ZR6AIC)
# GNU Radio version: 3.8.2.0

from gnuradio import analog
from gnuradio import gr
from gnuradio.filter import firdes
import sys
import signal
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
from gnuradio import eng_notation
import rpitx


class rptx_traqnsmitter(gr.top_block):

    def __init__(self):
        gr.top_block.__init__(self, "This is a demo of how to transmit with rpitx")

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 96000

        ##################################################
        # Blocks
        ##################################################
        self.rpitx_rpitx_source_0 = rpitx.rpitx_source(samp_rate, 145.3e6)
        self.analog_sig_source_x_0 = analog.sig_source_f(48000, analog.GR_COS_WAVE, 1000, 1, 0, 0)
        self.analog_nbfm_tx_0 = analog.nbfm_tx(
        	audio_rate=48000,
        	quad_rate=samp_rate,
        	tau=75e-6,
        	max_dev=2.5e3,
        	fh=-1.0,
                )



        ##################################################
        # Connections
        ##################################################
        self.connect((self.analog_nbfm_tx_0, 0), (self.rpitx_rpitx_source_0, 0))
        self.connect((self.analog_sig_source_x_0, 0), (self.analog_nbfm_tx_0, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate





def main(top_block_cls=rptx_traqnsmitter, options=None):
    tb = top_block_cls()

    def sig_handler(sig=None, frame=None):
        tb.stop()
        tb.wait()

        sys.exit(0)

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    tb.start()

    try:
        input('Press Enter to quit: ')
    except EOFError:
        pass
    tb.stop()
    tb.wait()


if __name__ == '__main__':
    main()
